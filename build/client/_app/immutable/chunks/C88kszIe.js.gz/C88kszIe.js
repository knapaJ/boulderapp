import{af as a}from"./BUBo3YVX.js";a();
