import{ag as a}from"./C1TBADaR.js";a();
