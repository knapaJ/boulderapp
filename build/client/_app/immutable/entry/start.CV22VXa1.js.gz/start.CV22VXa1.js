import{l as o,d as r}from"../chunks/CtsFDf-N.js";export{o as load_css,r as start};
