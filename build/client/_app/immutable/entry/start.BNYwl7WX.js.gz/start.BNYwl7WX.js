import{l as o,d as r}from"../chunks/HGIwls_L.js";export{o as load_css,r as start};
